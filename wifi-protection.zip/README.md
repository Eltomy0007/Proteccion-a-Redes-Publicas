# Proyecto: Proteccion de redes WiFi publicas (Entrega minima - 20%)

Resumen
------
Proyecto de demostracion que muestra medidas basicas de proteccion para redes WiFi publicas:
captive portal, endpoints REST en NestJS, registro de dispositivos y logs, y deteccion simple de evil twin.

Contenido del ZIP
-----------------
   -backend/ : Esqueleto de aplicacion NestJS (controladores y servicios monimos).
   -docker-compose.yml : Postgres + backend service (para demo).
   -docs/informe_proyecto.md : Documento del proyecto (version Markdown).
   -docs/postman_collection.json : Coleccion Postman (placeholder).
   -README.md` : Este archivo.

Instrucciones rapidas (entrega minima)
--------------------------------------
Requisitos:
   -Node.js >= 18
   -npm
   -Docker

1. Clonar el repo o descomprimir el ZIP.
2. Entrar a la carpeta backend:
   bash
   cd backend
   npm install
   npm run start:dev
3. Con docker-compose:
   bash
   docker compose up -d

Endpoints minimos
- POST /auth/login
- POST /auth/logout
- GET /devices
- POST /devices
- GET /logs

Evidencia y entrega (que subir al repo)
- README con instrucciones (este archivo).
- Codigo del backend (carpeta `backend/`).
- Captive portal estatico (puede colocarse en frontend/ o en backend/public/).
- Postman collection o curl examples (archivo en docs/).
- Screenshots o GIFs en docs/screenshots/.

