# Informe del proyecto - Proteccion de redes WiFi publicas

(Documento para incluir en docs/)

Incluye:
- Objetivos
- Alcance minimo 20%
- Tecnologias
- Estructura del repo
- Endpoints minimos
- Diagrama ER (adjuntar imagen si se desea)
- Plan de trabajo y cronograma
- Riesgos y mitigacion
