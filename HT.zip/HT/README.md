# nest-eventis-enhanced

Proyecto de ejemplo que implementa un puente HTTP -> WebSocket usando NestJS (Socket.IO).

Estructura principal:
- src/main.ts
- src/app.module.ts
- src/events/events.gateway.ts
- src/events/events.controller.ts
- src/events/events.module.ts

### Flujo
UserA -> HTTP POST /events/broadcast -> NestJS Controller -> EventsGateway -> WebSocket clients (UserB)

### Cómo usar (local)
1. Instalar dependencias:
   ```bash
   npm install
   ```
2. Ejecutar en modo desarrollo:
   ```bash
   npm run start:dev
   ```
3. Enviar mensaje vía HTTP (ejemplo):
   ```bash
   curl -X POST http://localhost:3000/events/broadcast \
     -H "Content-Type: application/json" \
     -d '{ "event": "my-event", "payload": { "from": "UserA", "text": "Hola UserB" } }'
   ```
4. Cliente WebSocket (Browser / Node) ejemplo:
   ```js
   // cliente.js o en consola del navegador
   const socket = io('http://localhost:3000');
   socket.on('connect', () => console.log('conectado', socket.id));
   socket.on('my-event', (data) => console.log('mensaje', data));
   ```
